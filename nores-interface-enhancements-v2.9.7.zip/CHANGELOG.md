# Changelog

## 2.9.7
* Finalize release
* Remove duplicate Compendium packs choice

## 2.9.6
* Fix ready hook migration so the module loads correctly in all worlds

## 2.9.5
* Replace Lower pause banner with Pause banner position dropdown with Default, Top, Bottom

## 2.9.4
* Correct pause banner centering

## 2.9.3
* Merge the working settings and sidebar logic with the hotbar reflow and the Module Management toolbar
* Keep batch check and uncheck safe so dependency prompts do not fire until Save Modules

## 2.9.2
* Force single row toolbar layout and remove change events from batch actions

## 2.9.1
* Align toolbar buttons to the right

## 2.9.0
* Combined working blocks into a single module
